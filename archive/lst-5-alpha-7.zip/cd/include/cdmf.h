#ifndef _CD_MF_
#define _CD_MF_

#ifdef __cplusplus
extern "C" {
#endif

cdContext* cdContextMetafile(void);

#define CD_METAFILE cdContextMetafile()

#ifdef __cplusplus
}
#endif

#endif /* ifndef _CD_MF_ */


