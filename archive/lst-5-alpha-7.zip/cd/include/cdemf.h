#ifndef _CD_EMF_
#define _CD_EMF_


#ifdef __cplusplus
extern "C" {
#endif

cdContext* cdContextEMF(void);

#define CD_EMF cdContextEMF()

#ifdef __cplusplus
}
#endif

#endif
