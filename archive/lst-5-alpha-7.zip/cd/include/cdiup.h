#ifndef _CD_IUP_
#define _CD_IUP_

#ifdef __cplusplus
extern "C" {
#endif

cdContext* cdContextIup(void);

#define CD_IUP cdContextIup()

#ifdef __cplusplus
}
#endif

#endif /* ifndef _CD_IUP_ */

