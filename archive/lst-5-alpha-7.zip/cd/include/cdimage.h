#ifndef _CD_IMAGE_
#define _CD_IMAGE_

#ifdef __cplusplus
extern "C" {
#endif

cdContext* cdContextImage(void);

#define CD_IMAGE cdContextImage()

#ifdef __cplusplus
}
#endif

#endif /* ifndef _CD_IMAGE_ */

