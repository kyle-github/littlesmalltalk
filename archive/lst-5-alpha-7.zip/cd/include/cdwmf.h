#ifndef _CD_WMF_
#define _CD_WMF_


#ifdef __cplusplus
extern "C" {
#endif

cdContext* cdContextWMF(void);

#define CD_WMF cdContextWMF()

#ifdef __cplusplus
}
#endif

#endif
