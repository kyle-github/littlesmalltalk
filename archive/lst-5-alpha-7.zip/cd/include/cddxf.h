#ifndef _CD_DXF_
#define _CD_DXF_

#ifdef __cplusplus
extern "C" {
#endif

cdContext* cdContextDXF(void);

#define CD_DXF cdContextDXF()

#ifdef __cplusplus
}
#endif

#endif /* ifndef _CD_DXF_ */
