#ifndef _CD_DGN_
#define _CD_DGN_

#ifdef __cplusplus
extern "C" {
#endif

cdContext* cdContextDGN(void);

#define CD_DGN cdContextDGN()

#ifdef __cplusplus
}
#endif

#endif /* ifndef _CD_DGN_ */

