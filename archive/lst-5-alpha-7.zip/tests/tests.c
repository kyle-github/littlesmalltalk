/*
 * Some simple tests...
 *
 */


#include <stdio.h>

int main(void)
{
  return 0;
}


